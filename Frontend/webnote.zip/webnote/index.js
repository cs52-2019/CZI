document.getElementById("openLoginPage").addEventListener("click", openLoginPage);

function openLoginPage() {
	location.href = "login.html";
}
